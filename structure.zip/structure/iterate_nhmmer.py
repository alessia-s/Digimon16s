#!/usr/bin/python3
import os
import subprocess
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("-f", "--folder", required=True) #permette di dichiarare la cartella in cui cercare gli fna, come argomento nel terminale
parser.add_argument("-q", "--query", required=True)     #permette di specificare se si vuole usare la query hmm per batteri o archea
args = parser.parse_args()
#args.folder è la cartella in cui cercare gli fna secondo quanto dichiarato negli argomenti.

if args.query.lower() in ["b", "ba", "bac", "bacteria"]:
    query = "bac.ssu.rnammer.hmm"
elif args.query.lower() in ["a", "ar", "arc", "archea"]:
    query = "arc.ssu.rnammer.hmm"
else:
    print("Please, choose a valid query argument")
    quit()

print("*************************************************** \n" 
      + "looking for FNA files in folder:", args.folder)
print("Query:", query, "\n")

FNA_list=[]  #crea una lista vuota per i file fna su cui vogliamo lavorare
for files in sorted(os.listdir(args.folder)):   #uno ad uno i file presenti nella cartella dove cercare gli fna
    #aggiungiamo alla lista dei file solo quelli con estensione fna, nel caso ci siano altri file nella cartella 
    	if len(str(files))>3 and (files[-3] + files[-2] + files [-1])=="fna":
            FNA_list.append(files)

processed_files = 0
processed_list = []
nhmmer_output_list = []

for i in FNA_list:
    print("processing", args.folder + "/%s" % i)
    subprocess.check_output(["nhmmer", "-E", "0.0001", "--dfamtblout=OUTPUTTEMP.txt", query , args.folder +"/%s" % i])
    processed_files += 1
    processed_list.append(i)
    nhmmer_output_list.append("@" + i +"\n" + open("OUTPUTTEMP.txt", "r").read())
    #open("OUTPUTTEMP.txt", "r").close()

with open("nhmmer_output_%s_%s.txt" % (args.folder, query[0:3]), "w") as f:
    print(*nhmmer_output_list, sep="\n", file=f)
os.remove("OUTPUTTEMP.txt")
print ("\nProcessed", processed_files, "files")
print("Output:", "nhmmer_output_%s_%s.txt" % (args.folder, query[0:3]), "\n")